-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: 157c_sys
-- ------------------------------------------------------
-- Server version	10.1.44-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
-- CREATE TABLE `ospos_permissions` (
--   `id` int(10) NOT NULL,
--   `module_key` varchar(250) CHARACTER SET utf8,
--   `permission_id` int(10) NOT NULL DEFAULT 0,
--   `module_id` int(10) NOT NULL DEFAULT 0,
-- ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- ALTER TABLE `ospos_permissions` ADD PRIMARY KEY( `id`); 
-- ALTER TABLE `ospos_permissions` CHANGE `id` `id` INT(10) NOT NULL AUTO_INCREMENT; 

-- CREATE TABLE `ospos_modules` (
--   `id` int(10) NOT NULL,
--   `module_id` varchar(250) CHARACTER SET utf8,
--   `name_lang_key` varchar(250) CHARACTER SET utf8,
--   `desc_lang_key` varchar(250) CHARACTER SET utf8,
--   `code` varchar(20) CHARACTER SET utf8,
--   `module_uuid` varchar(250) CHARACTER SET utf8 NOT NULL DEFAULT '0',
--   `created_at` int(11) NOT NULL DEFAULT 0,
--   `updated_at` int(11) NOT NULL DEFAULT 0,
--   `deleted_at` int(11) NOT NULL DEFAULT 0,
--   `status` tinyint(1) NOT NULL DEFAULT 1,
--   `name` text CHARACTER SET utf8 NOT NULL
-- ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- ALTER TABLE `ospos_modules` ADD PRIMARY KEY( `id`); 
-- ALTER TABLE `ospos_modules` CHANGE `id` `id` INT(10) NOT NULL AUTO_INCREMENT; 
ALTER TABLE `ospos_modules` DROP PRIMARY KEY;
ALTER TABLE `ospos_modules` ADD `id` INT(11) NOT NULL AUTO_INCREMENT AFTER `module_id`, ADD PRIMARY KEY (`id`);
ALTER TABLE `ospos_modules` ADD `code` VARCHAR(250) DEFAULT NULL AFTER `id`, ADD `name` VARCHAR(250) DEFAULT NULL AFTER `code`;
ALTER TABLE `ospos_modules` ADD `module_uuid` VARCHAR(250) NOT NULL DEFAULT UUID() AFTER `name`; 
ALTER TABLE `ospos_modules` ADD `created_at` INT(11) NOT NULL DEFAULT '0' AFTER `name`, ADD `updated_at` INT(11) NOT NULL DEFAULT '0' AFTER `created_at`, ADD `deleted_at` INT(11) NOT NULL DEFAULT '0' AFTER `updated_at`;
ALTER TABLE `ospos_modules` CHANGE `module_id` `module_key` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;


ALTER TABLE `ospos_permissions` DROP PRIMARY KEY;
ALTER TABLE `ospos_permissions` ADD `id` INT(11) NOT NULL AUTO_INCREMENT AFTER `location_id`, ADD PRIMARY KEY (`id`);
ALTER TABLE `ospos_permissions` ADD `module_key` VARCHAR(250) NOT NULL DEFAULT '\'\'' AFTER `id`;
ALTER TABLE `ospos_permissions` CHANGE `permission_id` `permission_key` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE `ospos_grants` CHANGE `person_id` `role_id` INT(11) NOT NULL;

ALTER TABLE `ospos_permissions` ADD `name` VARCHAR(250) DEFAULT NULL AFTER `module_key`;

-- ospos_permissions_ibfk_1
--ALTER TABLE `ospos_permissions` ADD `permission_uuid` VARCHAR(250) NOT NULL DEFAULT UUID() AFTER `name`; 
--ALTER TABLE `ospos_grants` DROP PRIMARY KEY;
--ALTER TABLE `ospos_grants` DROP INDEX `ospos_grants_ibfk_2`;
--ALTER TABLE `ospos_permissions` DROP INDEX `ospos_permissions_ibfk_1`;
--ALTER TABLE `ospos_permissions` DROP INDEX `ospos_permissions_ibfk_2`;

--select COLUMN_NAME, CONSTRAINT_NAME, REFERENCED_COLUMN_NAME, REFERENCED_TABLE_NAME
--from information_schema.KEY_COLUMN_USAGE
--where TABLE_NAME = `ospos_grants`; 


UPDATE ospos_permissions SET module_key = module_id;

UPDATE ospos_grants SET permission_id = (select p.id from ospos_permissions p where p.permission_key =  permission_id);


UPDATE ospos_grants SET role_id = 2 WHERE role_id = 7713;
UPDATE ospos_grants SET role_id = 3 WHERE role_id = 8794;
UPDATE ospos_grants SET role_id = 4 WHERE role_id = 8811;
UPDATE ospos_grants SET role_id = 5 WHERE role_id = 8817;
UPDATE ospos_grants SET role_id = 6 WHERE role_id = 8826;



-- ospos_sales_items
ALTER TABLE `ospos_sales_items` ADD `item_name` VARCHAR(250) DEFAULT NULL AFTER `item_location`;
ALTER TABLE `ospos_sales_items` ADD `item_category` VARCHAR(250) DEFAULT NULL AFTER `item_name`;
ALTER TABLE `ospos_sales_items` ADD `item_supplier_id` VARCHAR(12) DEFAULT NULL AFTER `item_name`;
ALTER TABLE `ospos_sales_items` ADD `item_number` VARCHAR(12) DEFAULT NULL AFTER `item_name`;
ALTER TABLE `ospos_sales_items` ADD `item_description` VARCHAR(12) DEFAULT NULL AFTER `item_name`;



/*
  supplier_id           | int(11)       | YES  | MUL | NULL    |                |
| item_number           | varchar(255)  | YES  | UNI | NULL    |                |
| description           | varchar(255)  | NO   |     | NULL    |                |
| cost_price            | decimal(15,2) | NO   |     | NULL    |                |
| unit_price            | decimal(15,2) | NO   | MUL | NULL    |                |
| reorder_level         | decimal(15,3) | NO   |     | 0.000   |                |
| receiving_quantity    | decimal(15,3) | NO   |     | 1.000   |                |
| item_id               | int(10)       | NO   | PRI | NULL    | auto_increment |
| pic_id                | int(10)       | YES  |     | NULL    |                |
| allow_alt_description | tinyint(1)    | NO   |     | NULL    |                |
| is_serialized   
*/

-- ospos_test
ALTER TABLE `ospos_test` ADD `test_uuid` VARCHAR(250) NOT NULL DEFAULT UUID() AFTER `expired_date`; 
--
-- ADD fields to ospos_sales
-- sale_uuid, confirm: 0,1,2; 0: don't confirm; 1: OK; 2: not OK
ALTER TABLE `ospos_sales` ADD `confirm` TINYINT(1) NOT NULL DEFAULT 0 AFTER `ctv_id`; 
ALTER TABLE `ospos_sales` ADD `sale_uuid` VARCHAR(250) NOT NULL DEFAULT UUID() AFTER `confirm`; 

ALTER TABLE `ospos_sales` ADD `kxv_id` int(11) DEFAULT '0' COMMENT '{0: mua hang ko kxv; > 0 mua hang co kxv}' AFTER `test_id`;
ALTER TABLE `ospos_sales` ADD `doctor_id` int(11) DEFAULT '0' COMMENT '{0: mua hang ko doctor; > 0 mua hang co doctor}' AFTER `kxv_id`;
ALTER TABLE `ospos_sales` ADD `paid_points` DECIMAL(10,2) NOT NULL DEFAULT '0' COMMENT 'Điểm dùng để thanh toán' AFTER `doctor_id`;
--
-- ADD fields to ospos_customers
ALTER TABLE `ospos_customers` ADD `points` DECIMAL(10,2) NOT NULL DEFAULT '0' AFTER `password`; 
ALTER TABLE `ospos_customers` ADD `customer_uuid` VARCHAR(250) NOT NULL DEFAULT UUID() AFTER `points`; 
--
-- Table structure for table `ospos_customers`
--

DROP TABLE IF EXISTS `ospos_short_survey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ospos_short_survey` (
  `id` int(10) NOT NULL,
  `customer_id` int(10),
  `sale_id` int(10),
  `sale_uuid` varchar(255) DEFAULT NULL,
  `nvbh_id` int(10) NOT NULL DEFAULT '0',
  `kxv_id` int(10) NOT NULL DEFAULT '0',
  `created_date` int(11) NOT NULL DEFAULT '0',
  `q1` int(1) NOT NULL DEFAULT '1',
  `q2` int(1) NOT NULL DEFAULT '1',
  `q3` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
ALTER TABLE `ospos_short_survey` ADD PRIMARY KEY( `id`); 
ALTER TABLE `ospos_short_survey` CHANGE `id` `id` INT(10) NOT NULL AUTO_INCREMENT; 
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `ospos_history_points`;

CREATE TABLE `ospos_history_points` (
  `id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL DEFAULT 0,
  `sale_id` int(10) NOT NULL DEFAULT 0,
  `sale_uuid` varchar(250) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `created_date` int(11) NOT NULL DEFAULT 0,
  `point` decimal(10,2) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `note` text CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
ALTER TABLE `ospos_history_points` ADD PRIMARY KEY( `id`); 
ALTER TABLE `ospos_history_points` CHANGE `id` `id` INT(10) NOT NULL AUTO_INCREMENT; 



DROP TABLE IF EXISTS `ospos_user_roles`;
CREATE TABLE `ospos_user_roles` (
  `id` int(10) NOT NULL,
  `role_id` int(10) NOT NULL DEFAULT 0,
  `user_id` int(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
ALTER TABLE `ospos_user_roles` ADD PRIMARY KEY( `id`); 
ALTER TABLE `ospos_user_roles` CHANGE `id` `id` INT(10) NOT NULL AUTO_INCREMENT; 

INSERT INTO `ospos_user_roles` (`role_id`, `user_id`) VALUES
('1', '1'),
('2', '7713'),
('3', '8794'),
('4', '8811'),
('5', '8817'),
('6', '8826');

DROP TABLE IF EXISTS `ospos_roles`;
CREATE TABLE `ospos_roles` (
  `id` int(10) NOT NULL,
  `name` varchar(250) CHARACTER SET utf8,
  `display_name` varchar(250) CHARACTER SET utf8,
  `code` varchar(20) CHARACTER SET utf8,
  `role_uuid` varchar(250) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL DEFAULT 0,
  `updated_at` int(11) NOT NULL DEFAULT 0,
  `deleted_at` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `description` text CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
ALTER TABLE `ospos_roles` ADD PRIMARY KEY( `id`); 
ALTER TABLE `ospos_roles` CHANGE `id` `id` INT(10) NOT NULL AUTO_INCREMENT; 

INSERT INTO `ospos_roles` (`name`, `display_name`,`code`, `created_at`, `updated_at`, `deleted_at`,`description`, `status`) VALUES
('admin', 'admin', 'ADM', NULL, NULL, NULL,1,'Admin Role'),
('Bán hàng', 'Bán hàng', 'SALE', NULL, NULL, NULL,1,'Bán hàng'),
('Thu ngân', 'Thu ngân', 'thungan', NULL, NULL, NULL,1,'Thu ngân'),
('Thủ kho', 'Thủ kho', 'thukho', NULL, NULL, NULL,1,'Thủ kho'),
('Quản lý', 'Quản lý', 'MGR', NULL, NULL, NULL,1,'Quản lý của hàng'),
('Nhà đầu tư', 'Nhà đầu tư', 'NDT', NULL, NULL, NULL,1,'Nhà đầu tư');


-- DROP TABLE IF EXISTS `ospos_role_permissions`;
-- CREATE TABLE `ospos_role_permissions` (
--   `id` int(10) NOT NULL,
--   `role_id` int(10) NOT NULL DEFAULT 0,
--   `permission_id` int(10) NOT NULL DEFAULT 0
-- ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- ALTER TABLE `ospos_role_permissions` ADD PRIMARY KEY( `id`); 
-- ALTER TABLE `ospos_role_permissions` CHANGE `id` `id` INT(10) NOT NULL AUTO_INCREMENT; 

DROP TABLE IF EXISTS `ospos_fields`;
CREATE TABLE `ospos_fields` (
  `id` int(10) NOT NULL,
  `field_key` varchar(250) CHARACTER SET utf8,
  `permission_id` int(10) NOT NULL DEFAULT 0,
  `permission_field` tinyint(1) NOT NULL DEFAULT 2
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
ALTER TABLE `ospos_fields` ADD PRIMARY KEY( `id`); 
ALTER TABLE `ospos_fields` CHANGE `id` `id` INT(10) NOT NULL AUTO_INCREMENT; 




--- Edit table vì đã tồn tại ----------
-- CREATE TABLE `ospos_permissions` (
--   `id` int(10) NOT NULL,
--   `module_key` varchar(250) CHARACTER SET utf8,
--   `permission_id` int(10) NOT NULL DEFAULT 0,
--   `module_id` int(10) NOT NULL DEFAULT 0,
-- ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- ALTER TABLE `ospos_permissions` ADD PRIMARY KEY( `id`); 
-- ALTER TABLE `ospos_permissions` CHANGE `id` `id` INT(10) NOT NULL AUTO_INCREMENT; 

-- CREATE TABLE `ospos_modules` (
--   `id` int(10) NOT NULL,
--   `module_id` varchar(250) CHARACTER SET utf8,
--   `name_lang_key` varchar(250) CHARACTER SET utf8,
--   `desc_lang_key` varchar(250) CHARACTER SET utf8,
--   `code` varchar(20) CHARACTER SET utf8,
--   `module_uuid` varchar(250) CHARACTER SET utf8 NOT NULL DEFAULT '0',
--   `created_at` int(11) NOT NULL DEFAULT 0,
--   `updated_at` int(11) NOT NULL DEFAULT 0,
--   `deleted_at` int(11) NOT NULL DEFAULT 0,
--   `status` tinyint(1) NOT NULL DEFAULT 1,
--   `name` text CHARACTER SET utf8 NOT NULL
-- ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- ALTER TABLE `ospos_modules` ADD PRIMARY KEY( `id`); 
-- ALTER TABLE `ospos_modules` CHANGE `id` `id` INT(10) NOT NULL AUTO_INCREMENT; 
--  ---------------