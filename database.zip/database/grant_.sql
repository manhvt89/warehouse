+--------------------+---------------+-------------+----+------------+
| permission_key     | module_id     | location_id | id | module_key |
+--------------------+---------------+-------------+----+------------+
| account            | account       |        NULL |  1 | ''         |
| account_admin      | account       |        NULL |  2 | ''         |
| account_create     | account       |        NULL |  3 | ''         |
| account_manage     | account       |        NULL |  4 | ''         |
| account_view       | account       |        NULL |  5 | ''         |
| config             | config        |        NULL |  6 | ''         |
| customers          | customers     |        NULL |  7 | ''         |
| customers_create   | customers     |        NULL |  8 | ''         |
| customers_edit     | customers     |        NULL |  9 | ''         |
| customers_manager  | customers     |        NULL | 10 | ''         |
| customers_remote   | customers     |        NULL | 11 | ''         |
| customers_view     | customers     |        NULL | 12 | ''         |
| customer_info      | customer_info |        NULL | 13 | ''         |
| employees          | employees     |        NULL | 14 | ''         |
| giftcards          | giftcards     |        NULL | 15 | ''         |
| items              | items         |        NULL | 16 | ''         |
| items_accounting   | items         |        NULL | 17 | ''         |

----------------------+------------------------+------+---------------+----+------+------+------------+------------+------------+--------------------------------------+
| name_lang_key        | desc_lang_key          | sort | module_key    | id | code | name | created_at | updated_at | deleted_at | module_uuid                          |
+----------------------+------------------------+------+---------------+----+------+------+------------+------------+------------+--------------------------------------+
| module_account       | module_account_desc    |  120 | account       |  1 | NULL | NULL |          0 |          0 |          0 | 50dccb4c-53bc-11ed-9e51-040300000000 |
| module_config        | module_config_desc     |  130 | config        |  2 | NULL | NULL |          0 |          0 |          0 | 50dccde6-53bc-11ed-9e51-040300000000 |
| module_customers     | module_customers_desc  |   10 | customers     |  3 | NULL | NULL |          0 |          0 |          0 | 50dccf7e-53bc-11ed-9e51-040300000000 |
| module_customer_info | module_customer_info   |  121 | customer_info |  4 | NULL | NULL |          0 |          0 |          0 | 50dcd055-53bc-11ed-9e51-040300000000 |
| module_employees     | module_employees_desc  |   80 | employees     |  5 | NULL | NULL |          0 |          0 |          0 | 50dcd113-53bc-11ed-9e51-040300000000 |
| module_giftcards     | module_giftcards_desc  |   90 | giftcards     |  6 | NULL | NULL |          0 |          0 |          0 | 50dcd1cf-53bc-11ed-9e51-040300000000 |
| module_items         | module_items_desc      |   20 | items         |  7 | NULL | NULL |          0 |          0 |          0 | 50dcd323-53bc-11ed-9e51-040300000000 |
| module_item_kits     | module_item_kits_desc  |   30 | item_kits     |  8 | NULL | NULL |          0 |          0 |          0 | 50dcd4bc-53bc-11ed-9e51-040300000000 |
| module_messages      | module_messages_desc   |  100 | messages      |  9 | NULL | NULL |          0 |          0 |          0 | 50dcd57b-53bc-11ed-9e51-040300000000 |
| module_order         | module_order_desc      |  150 | order         | 10 | NULL | NULL |          0 |          0 |          0 | 50dcd61c-53bc-11ed-9e51-040300000000 |
| module_receivings    | module_receivings_desc |   60 | receivings    | 11 | NULL | NULL |          0 |          0 |          0 | 50dcd6b8-53bc-11ed-9e51-040300000000 |
| module_reminders     | module_reminders_desc  |  140 | reminders     | 12 | NULL | NULL |          0 |          0 |          0 | 50dcd75f-53bc-11ed-9e51-040300000000 |
| module_reports       | module_reports_desc    |   50 | reports       | 13 | NULL | NULL |          0 |          0 |          0 | 50dcd80b-53bc-11ed-9e51-040300000000 |
| module_sales         | module_sales_desc      |   70 | sales         | 14 | NULL | NULL |          0 |          0 |          0 | 50dcd8ad-53bc-11ed-9e51-040300000000 |
| module_suppliers     | module_suppliers_desc  |   40 | suppliers     | 15 | NULL | NULL |          0 |          0 |          0 | 50dcd9b5-53bc-11ed-9e51-040300000000 |
| module_test          | module_test_desc       |  110 | test          | 16 | NULL | NULL |          0 |          0 |          0 | 50dcdaa6-53bc-11ed-9e51-040300000000 |
+----------------------+------------------------+------+---------------+----+------+------+------------+------------+------------+--------------------------------------+

7713 |
| 10            |    8794 |
| 10            |    8811 |
| 10            |    8817 |
| 10            |    8826 |


UPDATE ospos_grants SET role_id = 2 WHERE role_id = 7713;
UPDATE ospos_grants SET role_id = 3 WHERE role_id = 8794;
UPDATE ospos_grants SET role_id = 4 WHERE role_id = 8811;
UPDATE ospos_grants SET role_id = 5 WHERE role_id = 8817;
UPDATE ospos_grants SET role_id = 6 WHERE role_id = 8826;



SELECT g.* FROM ospos_grants g JOIN ospos_permissions p ON g.permission_id = p.id; 

(SELECT * FROM ospos_grants g JOINT ospos_permissions p ON g.permissions_id = p.id) 


SELECT ospos_modules.module_key, ospos_permissions.permission_key, ospos_roles.name FROM `ospos_modules`
  JOIN `ospos_permissions` ON `ospos_permissions`.`module_id` = `ospos_modules`.`module_key` 
  JOIN `ospos_grants` ON `ospos_permissions`.`id` = `ospos_grants`.`permission_id`
  JOIN ospos_roles ON ospos_roles.id = ospos_grants.role_id
  JOIN ospos_user_roles ON ospos_user_roles.role_id = ospos_roles.id


  WHERE `user_id` = '1' ORDER BY `sort` ASC







CREATE TABLE `permissions` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `display_name` varchar(100) DEFAULT NULL,
  `description` tinytext,
  `status` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `permission_roles`
--

CREATE TABLE `permission_roles` (
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `name` varchar(200) NOT NULL,
  `display_name` varchar(30) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'admin', 'admin', 'admin', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles_users`
--

CREATE TABLE `roles_users` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles_users`
--

INSERT INTO `roles_users` (`user_id`, `role_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `code` varchar(6) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `code`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'admin', 'admin', '$2y$10$ZMQOPfEVLtMrp51j9i3JBeKeOrOXEbvK/XZ2NYx48QqdM766dJBB.', '', 1, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `permission_roles`
--
ALTER TABLE `permission_roles`
  ADD PRIMARY KEY (`role_id`,`permission_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK_user_roles_role_Name` (`name`);

--
-- Indexes for table `roles_users`
--
ALTER TABLE `roles_users`
  ADD PRIMARY KEY (`user_id`,`role_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;